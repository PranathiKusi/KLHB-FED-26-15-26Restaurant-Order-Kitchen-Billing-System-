/*
 * DineSync - Smart Restaurant Management System with IoT-Based Kitchen Monitoring
 * File: Common.java  -> shared building blocks used by all four clusters
 * Syllabus: interface, abstract class, inheritance, custom exceptions (checked + unchecked),
 *           static members/constants, method overloading, Scanner input, try-catch, multi-catch
 */
import java.util.NoSuchElementException;
import java.util.Scanner;

public class Common {
    public static final String RESTAURANT_NAME = "DineSync Restaurant";
    public static final String VERSION = "1.0";

    private Common() { }                       // utility class, no objects

    static void line() { line('-', 60); }      // method overloading

    static void line(char ch, int length) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < length; i++) sb.append(ch);
        System.out.println(sb);
    }

    static String money(double amount) {
        return String.format("Rs %,.2f", amount);
    }
}

/* ---------- Interface: every module can produce a summary (CO4) ---------- */
interface Reportable {
    String generateReport();
}

/* ---------- Abstract class: common structure for all 13 modules (CO4) ---------- */
abstract class RestaurantModule implements Reportable {
    protected final String moduleCode;
    protected final String moduleName;

    RestaurantModule(String moduleCode, String moduleName) {
        this.moduleCode = moduleCode;
        this.moduleName = moduleName;
    }

    void displayModuleInfo() {             // concrete method shared by all
        System.out.println();
        Common.line('=', 60);
        System.out.printf("  [%s] %s%n", moduleCode, moduleName);
        Common.line('=', 60);
    }

    abstract void processModule();          // each module gives its own menu
}

/* ---------- Custom exceptions ---------- */
class DineSyncException extends Exception {             // checked
    DineSyncException(String message) { super(message); }
}

class InvalidInputException extends RuntimeException {  // unchecked
    InvalidInputException(String message) { super(message); }
}

/* ---------- Base class for Staff and Customer (hierarchical inheritance) ---------- */
abstract class Person {
    protected String id;
    protected String name;

    Person(String id, String name) {
        this.id = id;
        this.name = name;
    }

    String getId() { return id; }
    String getName() { return name; }

    abstract String getRole();

    @Override
    public String toString() {
        return String.format("%-6s %-18s %-10s", id, name, getRole());
    }
}

/* ---------- Console input helper using Scanner (CO1) ---------- */
class Input {
    private static final Scanner SC = new Scanner(System.in);

    private Input() { }

    static String readLine(String prompt) {
        System.out.print(prompt);
        try {
            return SC.nextLine().trim();
        } catch (NoSuchElementException | IllegalStateException e) {   // multi-catch
            System.out.println("\nInput closed. Exiting DineSync.");
            System.exit(0);
            return "";
        }
    }

    static int readInt(String prompt) {
        while (true) {
            String text = readLine(prompt);
            try {
                return Integer.parseInt(text);
            } catch (NumberFormatException e) {
                System.out.println("  ! Please enter a whole number.");
            }
        }
    }

    static double readDouble(String prompt) {
        while (true) {
            String text = readLine(prompt);
            try {
                return Double.parseDouble(text);
            } catch (NumberFormatException e) {
                System.out.println("  ! Please enter a valid number.");
            }
        }
    }

    static int readIntInRange(String prompt, int min, int max) {
        int value;
        do {
            value = readInt(prompt);
            if (value < min || value > max)
                System.out.printf("  ! Enter a value between %d and %d.%n", min, max);
        } while (value < min || value > max);
        return value;
    }

    static boolean readYesNo(String prompt) {
        while (true) {
            String ans = readLine(prompt + " (Y/N): ");
            if (ans.equalsIgnoreCase("Y")) return true;
            if (ans.equalsIgnoreCase("N")) return false;
            System.out.println("  ! Please type Y or N.");
        }
    }
}
