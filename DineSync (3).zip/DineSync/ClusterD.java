/*
 * DineSync - ClusterD.java
 * Cluster D: Monitoring, Energy and Analytics
 *   M10 Kitchen Sensor Monitoring (SIMULATED) -> Sensor + 4 subclasses, KitchenMonitor (2D array)
 *   M13 Kitchen Energy Meter                  -> Appliance, EnergyMeter (slab tariff)
 *   M08 Reports & Analytics                   -> ReportService (Streams, Collectors, bubble sort, file I/O)
 */
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/* ============================ M10 SENSORS ============================ */

abstract class Sensor {
    private final String name;
    private final String unit;
    protected final double threshold;

    Sensor(String name, String unit, double threshold) {
        this.name = name;
        this.unit = unit;
        this.threshold = threshold;
    }

    String getName() { return name; }
    String getUnit() { return unit; }

    abstract double read(Random rng);            // software-simulated reading

    boolean isAlert(double value) { return value > threshold; }

    String describeLimit() { return String.format("> %.0f %s", threshold, unit); }
}

class TemperatureSensor extends Sensor {
    TemperatureSensor() { super("Temperature", "degC", 45.0); }
    @Override double read(Random rng) { return 28 + rng.nextDouble() * 25; }
}

class GasSensor extends Sensor {
    GasSensor() { super("LPG Gas", "ppm", 1000.0); }
    @Override double read(Random rng) { return 200 + rng.nextDouble() * 1100; }
}

class SmokeSensor extends Sensor {
    SmokeSensor() { super("Smoke", "%obs", 8.0); }
    @Override double read(Random rng) { return rng.nextDouble() * 10; }
}

class HumiditySensor extends Sensor {
    static final double MIN = 30.0;
    HumiditySensor() { super("Humidity", "%RH", 75.0); }
    @Override double read(Random rng) { return 25 + rng.nextDouble() * 55; }
    @Override boolean isAlert(double value) { return value > threshold || value < MIN; }   // overriding
    @Override String describeLimit() { return String.format("< %.0f or > %.0f %s", MIN, threshold, getUnit()); }
}

class KitchenMonitor extends RestaurantModule {
    private final Sensor[] sensors = {new TemperatureSensor(), new GasSensor(), new SmokeSensor(), new HumiditySensor()};
    private final Random rng;
    private final List<String> alertLog = new ArrayList<>();
    private double[][] readings = new double[0][0];

    KitchenMonitor(long seed) {
        super("M10", "Kitchen Sensor Monitoring (SIMULATED)");
        this.rng = new Random(seed);             // fixed seed = repeatable test results
    }

    void runCycles(int cycles) {
        readings = new double[cycles][sensors.length];
        System.out.println("  NOTE: readings are simulated in software (java.util.Random), not physical sensors.");
        System.out.printf("  %-6s", "CYCLE");
        for (Sensor s : sensors) System.out.printf("%-20s", s.getName() + "(" + s.getUnit() + ")");
        System.out.println();

        int completed = 0;
        for (int c = 0; c < cycles; c++) {
            int alertsThisCycle = 0;
            System.out.printf("  %-6d", c + 1);
            for (int s = 0; s < sensors.length; s++) {
                double value = sensors[s].read(rng);       // runtime polymorphism
                readings[c][s] = value;
                boolean alert = sensors[s].isAlert(value);
                System.out.printf("%-20s", String.format("%8.1f %s", value, alert ? "ALERT" : "ok"));
                if (!alert) continue;
                alertsThisCycle++;
                alertLog.add(String.format("Cycle %d: %s = %.1f %s (limit %s)", c + 1,
                        sensors[s].getName(), value, sensors[s].getUnit(), sensors[s].describeLimit()));
            }
            System.out.println();
            completed++;
            if (alertsThisCycle >= 2) {
                System.out.println("  >>> CRITICAL: " + alertsThisCycle
                        + " alerts in one cycle. Raise alarm and cut gas supply. Monitoring stopped.");
                break;
            }
        }
        printSummary(completed);
    }

    private void printSummary(int rows) {                  // column-wise 2D array processing
        System.out.println("  Summary over " + rows + " cycle(s):");
        for (int s = 0; s < sensors.length; s++) {
            double sum = 0;
            double max = readings[0][s];
            for (int r = 0; r < rows; r++) {
                sum += readings[r][s];
                if (readings[r][s] > max) max = readings[r][s];
            }
            System.out.printf("  %-12s avg %8.1f   max %8.1f   limit %s%n",
                    sensors[s].getName(), sum / rows, max, sensors[s].describeLimit());
        }
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.Run monitoring cycles  2.Alert log  3.Thresholds  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 3);
            switch (ch) {
                case 1:
                    runCycles(Input.readIntInRange("Number of cycles (1-20): ", 1, 20));
                    break;
                case 2:
                    if (alertLog.isEmpty()) System.out.println("  No alerts recorded.");
                    alertLog.forEach(a -> System.out.println("  " + a));
                    break;
                case 3:
                    for (Sensor s : sensors) System.out.printf("  %-12s alert when %s%n", s.getName(), s.describeLimit());
                    break;
                default:
                    break;
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        return "M10 Sensor alerts      : " + alertLog.size() + " (simulated readings)";
    }
}

/* ============================ M13 ENERGY METER ============================ */

class Appliance {
    private final String name;
    private final int watts;
    private double hoursPerDay;

    Appliance(String name, int watts, double hoursPerDay) {
        if (watts <= 0) throw new InvalidInputException("Watts must be positive.");
        this.name = name;
        this.watts = watts;
        setHoursPerDay(hoursPerDay);
    }

    String getName() { return name; }
    int getWatts() { return watts; }
    double getHoursPerDay() { return hoursPerDay; }

    void setHoursPerDay(double hours) {
        if (hours < 0 || hours > 24) throw new InvalidInputException("Hours per day must be 0 to 24.");
        this.hoursPerDay = hours;
    }

    double dailyKwh() { return watts * hoursPerDay / 1000.0; }   // int * double -> double
}

class EnergyMeter extends RestaurantModule {
    static final int DAYS_IN_MONTH = 30;
    static final int SLAB1_LIMIT = 100;
    static final int SLAB2_LIMIT = 300;
    static final double SLAB1_RATE = 6.00;     // Rs/kWh (assumed tariff)
    static final double SLAB2_RATE = 7.50;
    static final double SLAB3_RATE = 9.00;

    private final List<Appliance> appliances = new ArrayList<>();

    EnergyMeter() {
        super("M13", "Kitchen Energy Meter");
        appliances.add(new Appliance("Commercial Refrigerator", 800, 24));
        appliances.add(new Appliance("Exhaust Fan", 250, 12));
        appliances.add(new Appliance("Rice Cooker", 1500, 3));
        appliances.add(new Appliance("Microwave Oven", 1200, 2));
        appliances.add(new Appliance("Mixer Grinder", 750, 2));
        appliances.add(new Appliance("Kitchen Lighting", 400, 12));
    }

    static double slabCost(double units) {
        if (units <= SLAB1_LIMIT) {
            return units * SLAB1_RATE;
        } else if (units <= SLAB2_LIMIT) {
            return SLAB1_LIMIT * SLAB1_RATE + (units - SLAB1_LIMIT) * SLAB2_RATE;
        } else {
            return SLAB1_LIMIT * SLAB1_RATE + (SLAB2_LIMIT - SLAB1_LIMIT) * SLAB2_RATE
                    + (units - SLAB2_LIMIT) * SLAB3_RATE;
        }
    }

    double totalDailyKwh() {
        double sum = 0;
        for (Appliance a : appliances) sum += a.dailyKwh();
        return sum;
    }

    void displayReport() {
        double totalDaily = totalDailyKwh();
        System.out.printf("  %-3s %-24s %6s %6s %9s %7s%n", "NO", "APPLIANCE", "WATTS", "HRS", "kWh/day", "SHARE");
        for (int i = 0; i < appliances.size(); i++) {
            Appliance a = appliances.get(i);
            double share = totalDaily == 0 ? 0 : a.dailyKwh() / totalDaily * 100;
            System.out.printf("  %-3d %-24s %6d %6.1f %9.2f %6.1f%%%n", i + 1, a.getName(),
                    a.getWatts(), a.getHoursPerDay(), a.dailyKwh(), share);
        }
        double monthlyUnits = totalDaily * DAYS_IN_MONTH;
        double monthlyCost = slabCost(monthlyUnits);
        Common.line();
        System.out.printf("  Daily consumption   : %.2f kWh%n", totalDaily);
        System.out.printf("  Monthly units (x%d) : %.2f kWh%n", DAYS_IN_MONTH, monthlyUnits);
        System.out.printf("  Monthly cost (slab) : %s%n", Common.money(monthlyCost));
        System.out.printf("  Approx. per day     : Rs %d%n", (int) Math.ceil(monthlyCost / DAYS_IN_MONTH));
        appliances.stream()
                .max(Comparator.comparingDouble(Appliance::dailyKwh))
                .ifPresent(a -> System.out.println("  Highest consumer    : " + a.getName()));
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.Energy report  2.Update hours  3.Add appliance  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 3);
            try {
                switch (ch) {
                    case 1:
                        displayReport();
                        break;
                    case 2: {
                        displayReport();
                        int no = Input.readIntInRange("Appliance number: ", 1, appliances.size());
                        appliances.get(no - 1).setHoursPerDay(Input.readDouble("New hours per day: "));
                        System.out.println("  Updated.");
                        break;
                    }
                    case 3: {
                        String name = Input.readLine("Appliance name: ");
                        int watts = Input.readIntInRange("Watts: ", 1, 10000);
                        double hrs = Input.readDouble("Hours per day: ");
                        appliances.add(new Appliance(name, watts, hrs));
                        System.out.println("  Appliance added.");
                        break;
                    }
                    default:
                        break;
                }
            } catch (InvalidInputException e) {
                System.out.println("  ! " + e.getMessage());
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        double daily = totalDailyKwh();
        return String.format("M13 Energy today       : %.2f kWh | est. monthly %s",
                daily, Common.money(slabCost(daily * DAYS_IN_MONTH)));
    }
}

/* ============================ M08 REPORTS ============================ */

class ReportService extends RestaurantModule {
    private static final Path REPORT_FILE = Paths.get("daily_report.txt");
    private final BillingService billing;
    private final FeedbackService feedback;
    private final MenuManager menu;
    private List<Reportable> sources = new ArrayList<>();

    ReportService(BillingService billing, FeedbackService feedback, MenuManager menu) {
        super("M08", "Reports & Analytics");
        this.billing = billing;
        this.feedback = feedback;
        this.menu = menu;
    }

    void setSources(List<Reportable> sources) { this.sources = sources; }

    static void bubbleSortDesc(String[] names, int[] qty) {      // manual sorting (CO3)
        for (int i = 0; i < qty.length - 1; i++) {
            boolean swapped = false;
            for (int j = 0; j < qty.length - 1 - i; j++) {
                if (qty[j] < qty[j + 1]) {
                    int t = qty[j]; qty[j] = qty[j + 1]; qty[j + 1] = t;
                    String s = names[j]; names[j] = names[j + 1]; names[j + 1] = s;
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
    }

    List<String> buildReport() {
        Supplier<String> header = () -> Common.RESTAURANT_NAME + " - DAILY REPORT";   // Supplier
        List<String> out = new ArrayList<>();
        out.add(header.get());
        out.add("------------------------------------------------------------");

        List<Bill> paid = billing.getPaidBills();
        double revenue = paid.stream().mapToDouble(Bill::getTotal).sum();
        double gst = paid.stream().map(b -> b.getCgst() + b.getSgst()).reduce(0.0, Double::sum);
        double discount = paid.stream().mapToDouble(Bill::getDiscount).sum();
        out.add(String.format("Paid bills         : %d", paid.size()));
        out.add(String.format("Total revenue      : %s", Common.money(revenue)));
        out.add(String.format("Average bill value : %s", Common.money(paid.isEmpty() ? 0 : revenue / paid.size())));
        out.add(String.format("GST collected      : %s", Common.money(gst)));
        out.add(String.format("Discounts given    : %s", Common.money(discount)));

        Map<String, Long> byMethod = paid.stream()
                .collect(Collectors.groupingBy(Bill::getPaymentMethod, TreeMap::new, Collectors.counting()));
        out.add("Payments by method : " + byMethod);

        Map<String, Integer> qtyByItem = new HashMap<>();
        for (Bill b : paid) {
            for (OrderItem oi : b.getLines()) {
                String n = oi.getItem().getName();
                qtyByItem.put(n, qtyByItem.getOrDefault(n, 0) + oi.getQuantity());
            }
        }
        String[] names = qtyByItem.keySet().toArray(new String[0]);
        int[] qty = new int[names.length];
        for (int i = 0; i < names.length; i++) qty[i] = qtyByItem.get(names[i]);
        bubbleSortDesc(names, qty);
        out.add("Top selling items  :");
        if (names.length == 0) out.add("   (no sales yet)");
        for (int i = 0; i < names.length && i < 3; i++) {
            out.add(String.format("   %d. %-22s %3d sold", i + 1, names[i], qty[i]));
        }

        Map<String, Long> byCategory = menu.getItems().stream()
                .collect(Collectors.groupingBy(MenuItem::getCategory, TreeMap::new, Collectors.counting()));
        out.add("Menu by category   : " + byCategory);
        String vegNames = menu.getItems().stream().filter(MenuItem::isVeg)
                .map(MenuItem::getName).sorted().collect(Collectors.joining(", "));
        out.add("Veg items          : " + vegNames);
        out.add(String.format("Average rating     : %.2f / 5", feedback.averageRating()));

        out.add("");
        out.add("MODULE SUMMARIES");
        for (Reportable r : sources) out.add(r.generateReport());      // interface polymorphism
        return out;
    }

    void saveReport(List<String> lines) {
        try {
            Files.write(REPORT_FILE, lines);
            long count;
            try (Stream<String> s = Files.lines(REPORT_FILE)) {         // file as stream
                count = s.count();
            }
            System.out.println("  Report saved to " + REPORT_FILE.toAbsolutePath() + " (" + count + " lines).");
        } catch (IOException e) {
            System.out.println("  ! Could not save report: " + e.getMessage());
        }
    }

    void readSavedReport() {
        if (!Files.exists(REPORT_FILE)) {
            System.out.println("  ! No saved report found. Save one first.");
            return;
        }
        try {
            List<String> lines = Files.readAllLines(REPORT_FILE);
            lines.forEach(l -> System.out.println("  " + l));
        } catch (IOException e) {
            System.out.println("  ! Could not read report: " + e.getMessage());
        }
    }

    void filterBillsByMethod(String method) {
        Predicate<Bill> matches = b -> b.getPaymentMethod().equalsIgnoreCase(method);       // Predicate
        Function<Bill, String> summary = b -> "Bill " + b.getBillNo() + " -> " + Common.money(b.getTotal()); // Function
        Consumer<String> printer = s -> System.out.println("  " + s);                       // Consumer
        List<String> rows = billing.getPaidBills().stream().filter(matches).map(summary).collect(Collectors.toList());
        if (rows.isEmpty()) System.out.println("  No paid bills with method " + method.toUpperCase() + ".");
        rows.forEach(printer);
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.View daily report  2.Save report to file  3.Bills by payment method  4.Read saved report  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 4);
            switch (ch) {
                case 1:
                    buildReport().forEach(System.out::println);
                    break;
                case 2:
                    saveReport(buildReport());
                    break;
                case 3:
                    filterBillsByMethod(Input.readLine("Method (CASH/CARD/UPI): "));
                    break;
                case 4:
                    readSavedReport();
                    break;
                default:
                    break;
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        return "M08 Reports module     : ready";
    }
}
