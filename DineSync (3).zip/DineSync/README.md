# DineSync

**Smart Restaurant Management System with IoT-Based Kitchen Monitoring**
Core Java console project for Problem Solving Using Programming (Java), course code 26SC1101E.

## How to run

Requires JDK 17 or later (tested on JDK 21).

```
javac *.java
java DineSyncMain
```

Demo logins:

| Role | Username | Password |
|---|---|---|
| Manager | manager | admin123 |
| Waiter | waiter | wait123 |
| Chef | chef | chef123 |

Choose option **12** in the main menu to run the full end-to-end demo.

## Files

| File | Contents |
|---|---|
| `Common.java` | Shared interface, abstract class, custom exceptions, `Person` base class, Scanner input helper |
| `ClusterA.java` | M01 Login, M02 Menu, M03 Customers, M09 Table Register |
| `ClusterB.java` | M04 Order Taking, M05 Kitchen Queue, M11 Seven-Segment Token |
| `ClusterC.java` | M06 Billing & Payment, M12 Bill Checksum, M07 Feedback |
| `ClusterD.java` | M10 Kitchen Sensors (simulated), M13 Energy Meter, M08 Reports |
| `DineSyncMain.java` | Main class: login, role-based menu, end-to-end demo |

The program creates `menu.csv`, `bills.txt` and `daily_report.txt` at runtime.

## Notes

- Kitchen sensor readings are simulated in software with `java.util.Random`. No physical sensors are connected.
- GST rates, loyalty discount slabs, sensor thresholds and the electricity tariff are assumed values set as constants in the code.
- The bill checksum is a simple mod-97 integrity check for learning purposes, not cryptographic security.
