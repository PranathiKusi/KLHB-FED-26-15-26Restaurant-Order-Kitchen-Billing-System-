/*
 * DineSync - ClusterB.java
 * Cluster B: Ordering, Kitchen and Token Display
 *   M04 Order Taking             -> OrderItem, Order, OrderService
 *   M05 Kitchen Queue            -> KitchenQueue
 *   M11 Seven-Segment Token      -> SevenSegmentDisplay (bitwise + recursion)
 * Order lifecycle: PLACED -> PREPARING -> READY -> SERVED -> BILLED
 */
import java.util.*;
import java.util.stream.Collectors;

class OrderItem {
    private final MenuItem item;
    private int quantity;

    OrderItem(MenuItem item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }

    MenuItem getItem() { return item; }
    int getQuantity() { return quantity; }
    void addQuantity(int q) { quantity += q; }
    double lineTotal() { return item.getPrice() * quantity; }

    @Override
    public String toString() {
        return String.format("%-22s x%-3d %9.2f", item.getName(), quantity, lineTotal());
    }
}

class Order {
    static final String[] STATUS = {"PLACED", "PREPARING", "READY", "SERVED", "BILLED"};
    private static int nextOrderId = 101;          // static counter shared by all orders

    private final int orderId;
    private final int tableNo;
    private final Customer customer;              // null = walk-in guest
    private final List<OrderItem> items = new ArrayList<>();
    private int statusIndex = 0;
    private String chef = "-";

    Order(int tableNo, Customer customer) {
        this.orderId = nextOrderId++;
        this.tableNo = tableNo;
        this.customer = customer;
    }

    int getOrderId() { return orderId; }
    int getTableNo() { return tableNo; }
    int getToken() { return orderId; }
    Customer getCustomer() { return customer; }
    List<OrderItem> getItems() { return items; }
    String getStatus() { return STATUS[statusIndex]; }
    String getChef() { return chef; }
    void setChef(String chef) { this.chef = chef; }

    boolean isPriority() {
        return customer != null && customer.getLoyaltyPoints() >= 100;
    }

    void addItem(MenuItem m, int qty) {
        for (OrderItem oi : items) {
            if (oi.getItem().getCode().equals(m.getCode())) {
                oi.addQuantity(qty);
                return;
            }
        }
        items.add(new OrderItem(m, qty));
    }

    double subtotal() {
        double sum = 0;
        for (OrderItem oi : items) sum += oi.lineTotal();
        return sum;
    }

    int itemCount() {
        int count = 0;
        for (OrderItem oi : items) count += oi.getQuantity();
        return count;
    }

    private static int indexOf(String status) {
        for (int i = 0; i < STATUS.length; i++) {
            if (STATUS[i].equals(status)) return i;
        }
        return -1;
    }

    void moveTo(String newStatus) throws DineSyncException {   // only the next stage is allowed
        int target = indexOf(newStatus);
        if (target != statusIndex + 1)
            throw new DineSyncException(String.format("Order %d cannot move from %s to %s.",
                    orderId, getStatus(), newStatus));
        statusIndex = target;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("  Order #%d | Table %d | %s | %s | Chef: %s%n", orderId, tableNo,
                customer == null ? "Walk-in" : customer.getName(), getStatus(), chef));
        for (OrderItem oi : items) sb.append("     ").append(oi).append(System.lineSeparator());
        sb.append("     Subtotal: ").append(Common.money(subtotal()));
        return sb.toString();
    }
}

/* ============================ M04 ORDER TAKING ============================ */

class OrderService extends RestaurantModule {
    static final int MAX_QTY = 20;
    private final MenuManager menu;
    private final CustomerManager customers;
    private final TableRegister tables;
    private final KitchenQueue kitchen;
    private final List<Order> orders = new ArrayList<>();

    OrderService(MenuManager menu, CustomerManager customers, TableRegister tables, KitchenQueue kitchen) {
        super("M04", "Order Taking");
        this.menu = menu;
        this.customers = customers;
        this.tables = tables;
        this.kitchen = kitchen;
    }

    Order createOrder(int tableNo, Customer c) throws DineSyncException {
        if (!tables.isOccupied(tableNo))
            throw new DineSyncException("Allocate table " + tableNo + " before taking an order.");
        return new Order(tableNo, c);
    }

    void addItem(Order order, String code) throws DineSyncException {        // overloaded: qty = 1
        addItem(order, code, 1);
    }

    void addItem(Order order, String code, int qty) throws DineSyncException {
        MenuItem m = menu.findByCode(code);
        if (m == null) throw new DineSyncException("No menu item with code " + code + ".");
        if (!m.isAvailable()) throw new DineSyncException(m.getName() + " is currently unavailable.");
        if (qty < 1 || qty > MAX_QTY) throw new DineSyncException("Quantity must be 1 to " + MAX_QTY + ".");
        Customer c = order.getCustomer();
        if (c != null && c.isVegetarian() && !m.isVeg())
            throw new DineSyncException(c.getName() + " is vegetarian. " + m.getName() + " is non-veg.");
        order.addItem(m, qty);
    }

    void submit(Order order) throws DineSyncException {
        if (order.getItems().isEmpty()) throw new DineSyncException("Cannot submit an empty order.");
        orders.add(order);
        kitchen.enqueue(order);
        if (order.getCustomer() != null) order.getCustomer().incrementVisits();
    }

    Optional<Order> findOrder(int id) {
        return orders.stream().filter(o -> o.getOrderId() == id).findFirst();
    }

    List<Order> getOrders() { return orders; }

    @Override
    void processModule() {
        displayModuleInfo();
        tables.displayRegister();
        int tableNo = Input.readIntInRange("Table number (1-8): ", 1, TableRegister.TABLE_COUNT);
        if (!tables.isOccupied(tableNo)) {
            if (!Input.readYesNo("Table is free. Allocate it now?")) return;
            try {
                tables.allocate(tableNo);
            } catch (DineSyncException e) {
                System.out.println("  ! " + e.getMessage());
                return;
            }
        }

        String phone = Input.readLine("Customer phone (press Enter for walk-in): ");
        Customer c = phone.isEmpty() ? null : customers.find(phone);
        if (!phone.isEmpty() && c == null) System.out.println("  ! Customer not found. Treating as walk-in.");
        if (c != null && !c.getFavourites().isEmpty()) System.out.println("  Favourites: " + c.getFavourites());

        Order order;
        try {
            order = createOrder(tableNo, c);
        } catch (DineSyncException e) {
            System.out.println("  ! " + e.getMessage());
            return;
        }

        menu.display(menu.getAvailableItems());
        while (true) {
            String code = Input.readLine("Item code (0 to finish): ").toUpperCase();
            if (code.equals("0")) break;
            int qty = Input.readInt("Quantity: ");
            try {
                addItem(order, code, qty);
                System.out.println("  + added");
            } catch (DineSyncException e) {
                System.out.println("  ! " + e.getMessage());
            }
        }

        try {
            submit(order);
            System.out.println(order);
            System.out.println("  Order sent to kitchen. Token number:");
            SevenSegmentDisplay.show(order.getToken());
        } catch (DineSyncException e) {
            System.out.println("  ! " + e.getMessage());
        }
    }

    @Override
    public String generateReport() {
        Map<String, Long> byStatus = orders.stream()
                .collect(Collectors.groupingBy(Order::getStatus, TreeMap::new, Collectors.counting()));
        return "M04 Orders placed      : " + orders.size() + " " + byStatus;
    }
}

/* ============================ M05 KITCHEN QUEUE ============================ */

class KitchenQueue extends RestaurantModule {
    private final String[] chefs = {"Suresh", "Meena", "Arjun"};
    private int nextChef = 0;
    private final List<Order> queue = new ArrayList<>();

    KitchenQueue() {
        super("M05", "Kitchen Queue");
    }

    void enqueue(Order o) {
        queue.add(o);
        // loyal customers first, then first-come-first-served
        queue.sort(Comparator.comparing((Order x) -> !x.isPriority()).thenComparingInt(Order::getOrderId));
    }

    private Order find(int orderId) throws DineSyncException {
        Iterator<Order> it = queue.iterator();                  // Iterator traversal
        while (it.hasNext()) {
            Order o = it.next();
            if (o.getOrderId() == orderId) return o;
        }
        throw new DineSyncException("Order " + orderId + " is not in the kitchen queue.");
    }

    Order startOrder(int orderId) throws DineSyncException {
        Order o = find(orderId);
        o.moveTo("PREPARING");
        o.setChef(chefs[nextChef]);
        nextChef = (nextChef + 1) % chefs.length;               // round-robin chef assignment
        return o;
    }

    Order startNext() throws DineSyncException {
        for (Order o : queue) {
            if (o.getStatus().equals("PLACED")) return startOrder(o.getOrderId());
        }
        throw new DineSyncException("No orders are waiting to be prepared.");
    }

    Order markReady(int orderId) throws DineSyncException {
        Order o = find(orderId);
        o.moveTo("READY");
        return o;
    }

    Order markServed(int orderId) throws DineSyncException {
        Order o = find(orderId);
        o.moveTo("SERVED");
        queue.remove(o);
        return o;
    }

    void displayQueue() {
        if (queue.isEmpty()) {
            System.out.println("  Kitchen queue is empty.");
            return;
        }
        System.out.printf("  %-6s %-6s %-10s %-8s %-6s %s%n", "ORDER", "TABLE", "STATUS", "CHEF", "QTY", "PRIORITY");
        for (Order o : queue) {
            System.out.printf("  %-6d %-6d %-10s %-8s %-6d %s%n", o.getOrderId(), o.getTableNo(),
                    o.getStatus(), o.getChef(), o.itemCount(), o.isPriority() ? "YES (loyal)" : "-");
        }
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.View queue  2.Start next order  3.Mark READY  4.Mark SERVED  5.Show digit segments  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 5);
            try {
                switch (ch) {
                    case 1:
                        displayQueue();
                        break;
                    case 2: {
                        Order o = startNext();
                        System.out.printf("  Order %d is now PREPARING (chef %s).%n", o.getOrderId(), o.getChef());
                        break;
                    }
                    case 3: {
                        Order o = markReady(Input.readInt("Order ID: "));
                        System.out.println("  Order READY. Token display:");
                        SevenSegmentDisplay.show(o.getToken());
                        break;
                    }
                    case 4: {
                        Order o = markServed(Input.readInt("Order ID: "));
                        System.out.println("  Order " + o.getOrderId() + " SERVED to table " + o.getTableNo() + ".");
                        break;
                    }
                    case 5: {
                        int d = Input.readIntInRange("Digit 0-9: ", 0, 9);
                        System.out.println("  Segment code (gfedcba): " + SevenSegmentDisplay.segmentBits(d));
                        SevenSegmentDisplay.show(d);
                        break;
                    }
                    default:
                        break;
                }
            } catch (DineSyncException e) {
                System.out.println("  ! " + e.getMessage());
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        return "M05 Kitchen queue      : " + queue.size() + " active | chefs " + String.join(", ", chefs);
    }
}

/* ============================ M11 SEVEN-SEGMENT TOKEN ============================ */

class SevenSegmentDisplay {
    // bit0=a(top) bit1=b bit2=c bit3=d(bottom) bit4=e bit5=f bit6=g(middle)
    private static final int[] DIGIT_CODES = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};

    private SevenSegmentDisplay() { }

    static boolean segmentOn(int code, int bit) {
        return ((code >> bit) & 1) == 1;
    }

    static String segmentBits(int digit) {
        String bin = Integer.toBinaryString(DIGIT_CODES[digit]);
        while (bin.length() < 7) bin = "0" + bin;
        return bin;
    }

    static void collectDigits(int n, List<Integer> digits) {   // recursion
        if (n < 10) {                       // base case
            digits.add(n);
            return;
        }
        collectDigits(n / 10, digits);      // recursive case
        digits.add(n % 10);
    }

    static String[] render(int number) {
        List<Integer> digits = new ArrayList<>();
        collectDigits(Math.abs(number), digits);
        StringBuilder top = new StringBuilder();
        StringBuilder mid = new StringBuilder();
        StringBuilder bot = new StringBuilder();
        for (int d : digits) {              // auto-unboxing
            int c = DIGIT_CODES[d];
            top.append(' ').append(segmentOn(c, 0) ? '_' : ' ').append("  ");
            mid.append(segmentOn(c, 5) ? '|' : ' ').append(segmentOn(c, 6) ? '_' : ' ')
               .append(segmentOn(c, 1) ? '|' : ' ').append(' ');
            bot.append(segmentOn(c, 4) ? '|' : ' ').append(segmentOn(c, 3) ? '_' : ' ')
               .append(segmentOn(c, 2) ? '|' : ' ').append(' ');
        }
        return new String[]{top.toString(), mid.toString(), bot.toString()};
    }

    static void show(int token) {
        System.out.println("  +---- TOKEN ----+");
        for (String row : render(token)) System.out.println("     " + row);
        System.out.println("  +---------------+");
    }
}
