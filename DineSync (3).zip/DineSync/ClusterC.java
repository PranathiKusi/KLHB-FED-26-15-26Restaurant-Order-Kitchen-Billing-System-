/*
 * DineSync - ClusterC.java
 * Cluster C: Billing, Payment, Checksum and Feedback
 *   M06 Billing & Payment       -> Bill, BillingService
 *   M12 Bill Checksum Security  -> BillChecksum (recursion, modulus)
 *   M07 Feedback & Ratings      -> Feedback, FeedbackService
 */
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.*;
import java.util.stream.Collectors;

/* ============================ M12 CHECKSUM ============================ */

class BillChecksum {
    static final int MODULUS = 97;

    private BillChecksum() { }

    // weighted digit sum from the rightmost digit, weights 1,2,3...
    static int weightedDigitSum(long n, int weight) {
        if (n == 0) return 0;                                                   // base case
        return (int) (n % 10) * weight + weightedDigitSum(n / 10, weight + 1);  // recursive case
    }

    static int compute(int billNo, double amount) {
        long paise = Math.round(amount * 100);     // 807.98 -> 80798 (avoids floating error)
        return (weightedDigitSum(paise, 1) + billNo * 7) % MODULUS;
    }

    static boolean verify(int billNo, double amount, int checksum) {
        return compute(billNo, amount) == checksum;
    }

    static String format(int checksum) {
        return String.format("DS-%02d", checksum);
    }
}

/* ============================ M06 BILLING ============================ */

class Bill {
    private static int nextBillNo = 1;

    private final int billNo;
    private final int orderId;
    private final int tableNo;
    private final String customerName;
    private final List<OrderItem> lines;
    private final double subtotal;
    private final double discountRate;
    private final double discount;
    private final double cgst;
    private final double sgst;
    private final double total;
    private final int checksum;
    private String paymentMethod = "UNPAID";
    private boolean paid = false;

    Bill(Order order, double discountRate) {
        this.billNo = nextBillNo++;
        this.orderId = order.getOrderId();
        this.tableNo = order.getTableNo();
        this.customerName = order.getCustomer() == null ? "Walk-in" : order.getCustomer().getName();
        this.lines = new ArrayList<>(order.getItems());
        this.subtotal = round2(order.subtotal());
        this.discountRate = discountRate;
        this.discount = round2(subtotal * discountRate);
        double taxable = subtotal - discount;
        this.cgst = round2(taxable * BillingService.CGST_RATE);
        this.sgst = round2(taxable * BillingService.SGST_RATE);
        this.total = round2(taxable + cgst + sgst);
        this.checksum = BillChecksum.compute(billNo, total);
    }

    static double round2(double v) {
        return Math.round(v * 100) / 100.0;        // long / double -> double
    }

    int getBillNo() { return billNo; }
    int getOrderId() { return orderId; }
    List<OrderItem> getLines() { return lines; }
    double getSubtotal() { return subtotal; }
    double getDiscount() { return discount; }
    double getCgst() { return cgst; }
    double getSgst() { return sgst; }
    double getTotal() { return total; }
    int getChecksum() { return checksum; }
    String getPaymentMethod() { return paymentMethod; }
    boolean isPaid() { return paid; }

    void markPaid(String method) {
        this.paymentMethod = method;
        this.paid = true;
    }

    String toCsv() {
        return String.join(",", String.valueOf(billNo), String.valueOf(orderId), customerName,
                String.valueOf(subtotal), String.valueOf(discount), String.valueOf(cgst),
                String.valueOf(sgst), String.valueOf(total), paymentMethod, BillChecksum.format(checksum));
    }

    void print() {
        Common.line('=', 50);
        System.out.printf("  %s - TAX INVOICE%n", Common.RESTAURANT_NAME);
        System.out.printf("  Bill No: %d   Order: %d   Table: %d%n", billNo, orderId, tableNo);
        System.out.println("  Customer: " + customerName);
        Common.line('-', 50);
        for (OrderItem oi : lines) System.out.println("  " + oi);
        Common.line('-', 50);
        System.out.printf("  %-32s %12.2f%n", "Subtotal", subtotal);
        System.out.printf("  %-32s %12.2f%n",
                String.format("Loyalty discount (%.0f%%)", discountRate * 100), discount == 0 ? 0.0 : -discount);
        System.out.printf("  %-32s %12.2f%n", String.format("CGST @ %.1f%%", BillingService.CGST_RATE * 100), cgst);
        System.out.printf("  %-32s %12.2f%n", String.format("SGST @ %.1f%%", BillingService.SGST_RATE * 100), sgst);
        Common.line('-', 50);
        System.out.printf("  %-32s %12.2f%n", "GRAND TOTAL (Rs)", total);
        System.out.printf("  Payment: %-8s  Checksum: %s%n", paymentMethod, BillChecksum.format(checksum));
        Common.line('=', 50);
    }
}

class BillingService extends RestaurantModule {
    static final double CGST_RATE = 0.025;
    static final double SGST_RATE = 0.025;
    private static final Path BILL_FILE = Paths.get("bills.txt");

    private final OrderService orders;
    private final TableRegister tables;
    private final List<Bill> bills = new ArrayList<>();

    BillingService(OrderService orders, TableRegister tables) {
        super("M06", "Billing & Payment + M12 Checksum");
        this.orders = orders;
        this.tables = tables;
    }

    static double loyaltyDiscountRate(Customer c) {      // if-else-if ladder
        if (c == null) return 0.0;
        int pts = c.getLoyaltyPoints();
        if (pts >= 200) return 0.10;
        else if (pts >= 100) return 0.05;
        else return 0.0;
    }

    Bill generateBill(int orderId) throws DineSyncException {
        Order o = orders.findOrder(orderId)
                .orElseThrow(() -> new DineSyncException("Order " + orderId + " not found."));
        for (Bill b : bills) {
            if (b.getOrderId() == orderId) {
                if (b.isPaid()) throw new DineSyncException("Order " + orderId + " is already billed and paid.");
                return b;                                  // reuse unpaid bill
            }
        }
        if (!o.getStatus().equals("SERVED"))
            throw new DineSyncException("Order " + orderId + " is " + o.getStatus() + ". Only SERVED orders can be billed.");
        Bill bill = new Bill(o, loyaltyDiscountRate(o.getCustomer()));
        bills.add(bill);
        return bill;
    }

    double pay(Bill bill, int method, double tendered) throws DineSyncException {
        if (bill.isPaid()) throw new DineSyncException("Bill " + bill.getBillNo() + " is already paid.");
        if (!BillChecksum.verify(bill.getBillNo(), bill.getTotal(), bill.getChecksum()))
            throw new DineSyncException("Checksum mismatch. Bill " + bill.getBillNo() + " may be altered.");

        String methodName;
        double change = 0;
        switch (method) {
            case 1:
                if (tendered < bill.getTotal())
                    throw new DineSyncException("Insufficient cash. Need " + Common.money(bill.getTotal())
                            + ", received " + Common.money(tendered) + ".");
                methodName = "CASH";
                change = Bill.round2(tendered - bill.getTotal());
                break;
            case 2:
                methodName = "CARD";
                break;
            case 3:
                methodName = "UPI";
                break;
            default:
                throw new DineSyncException("Unknown payment method " + method + ".");
        }

        Order order = orders.findOrder(bill.getOrderId())
                .orElseThrow(() -> new DineSyncException("Order missing for this bill."));
        order.moveTo("BILLED");
        bill.markPaid(methodName);
        Customer c = order.getCustomer();
        if (c != null) c.addLoyaltyPoints((int) (bill.getTotal() / 10));   // 1 point per Rs 10
        if (tables.isOccupied(order.getTableNo())) tables.release(order.getTableNo());
        appendToFile(bill);
        return change;
    }

    private void appendToFile(Bill bill) {
        try {
            Files.write(BILL_FILE, Collections.singletonList(bill.toCsv()),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.out.println("  ! Could not save bill: " + e.getMessage());
        }
    }

    Optional<Bill> findBill(int billNo) {
        return bills.stream().filter(b -> b.getBillNo() == billNo).findFirst();
    }

    boolean isPaid(int orderId) {
        for (Bill b : bills) {
            if (b.getOrderId() == orderId && b.isPaid()) return true;
        }
        return false;
    }

    List<Bill> getPaidBills() {
        return bills.stream().filter(Bill::isPaid).collect(Collectors.toList());
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.Generate & pay bill  2.Verify bill checksum  3.List bills  4.Tamper test  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 4);
            switch (ch) {
                case 1: {
                    int id = Input.readInt("Order ID: ");
                    try {
                        Bill bill = generateBill(id);
                        bill.print();
                        int method = Input.readIntInRange("Payment 1-Cash 2-Card 3-UPI: ", 1, 3);
                        double tendered = (method == 1) ? Input.readDouble("Cash received: ") : bill.getTotal();
                        double change = pay(bill, method, tendered);
                        System.out.println("  Payment successful via " + bill.getPaymentMethod() + ".");
                        if (method == 1) System.out.println("  Change to return: " + Common.money(change));
                    } catch (DineSyncException e) {
                        System.out.println("  ! " + e.getMessage());
                    } finally {
                        System.out.println("  (billing transaction closed)");
                    }
                    break;
                }
                case 2: {
                    int no = Input.readInt("Bill number: ");
                    double amt = Input.readDouble("Amount printed on bill: ");
                    int chk = Input.readInt("Checksum number (e.g. 94 for DS-94): ");
                    System.out.println(BillChecksum.verify(no, amt, chk)
                            ? "  VALID - bill is genuine." : "  INVALID - details do not match checksum.");
                    break;
                }
                case 3:
                    if (bills.isEmpty()) System.out.println("  No bills yet.");
                    for (Bill b : bills) {
                        System.out.printf("  Bill %d | Order %d | %s | %s | %s%n", b.getBillNo(), b.getOrderId(),
                                Common.money(b.getTotal()), b.getPaymentMethod(), BillChecksum.format(b.getChecksum()));
                    }
                    break;
                case 4: {
                    if (bills.isEmpty()) { System.out.println("  Generate a bill first."); break; }
                    Bill b = bills.get(bills.size() - 1);
                    double fake = b.getTotal() - 50;
                    System.out.printf("  Original amount %.2f -> %s%n", b.getTotal(),
                            BillChecksum.verify(b.getBillNo(), b.getTotal(), b.getChecksum()) ? "VALID" : "INVALID");
                    System.out.printf("  Altered amount  %.2f -> %s%n", fake,
                            BillChecksum.verify(b.getBillNo(), fake, b.getChecksum()) ? "VALID" : "INVALID");
                    break;
                }
                default:
                    break;
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        return "M06 Bills              : generated " + bills.size() + " | paid " + getPaidBills().size();
    }
}

/* ============================ M07 FEEDBACK ============================ */

class Feedback {
    private final int orderId;
    private final int rating;
    private final String comment;

    Feedback(int orderId, int rating, String comment) {
        this.orderId = orderId;
        this.rating = rating;
        this.comment = comment;
    }

    int getOrderId() { return orderId; }
    int getRating() { return rating; }
    String getComment() { return comment; }

    String stars() {
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 5; i++) sb.append(i <= rating ? '*' : '.');
        return sb.toString();
    }

    @Override
    public String toString() {
        return String.format("Order %d  %s  \"%s\"", orderId, stars(), comment);
    }
}

class FeedbackService extends RestaurantModule {
    private final List<Feedback> feedbacks = new ArrayList<>();
    private final Set<Integer> ratedOrders = new HashSet<>();   // duplicate prevention
    private final BillingService billing;

    FeedbackService(BillingService billing) {
        super("M07", "Feedback & Ratings");
        this.billing = billing;
    }

    void submit(int orderId, int rating, String comment) throws DineSyncException {
        if (!billing.isPaid(orderId)) throw new DineSyncException("Feedback is allowed only after payment.");
        if (ratedOrders.contains(orderId)) throw new DineSyncException("Feedback already recorded for order " + orderId + ".");
        if (rating < 1 || rating > 5) throw new DineSyncException("Rating must be 1 to 5.");
        String clean = (comment == null) ? "" : comment.trim();
        if (clean.length() > 100) clean = clean.substring(0, 100);
        feedbacks.add(new Feedback(orderId, rating, clean));
        ratedOrders.add(orderId);                                // autoboxing int -> Integer
    }

    double averageRating() {
        return feedbacks.stream().mapToInt(Feedback::getRating).average().orElse(0.0);
    }

    int[] distribution() {                                       // counting with 1D array
        int[] count = new int[6];
        for (Feedback f : feedbacks) count[f.getRating()]++;
        return count;
    }

    void showSummary() {
        int[] dist = distribution();
        for (int r = 5; r >= 1; r--) {                           // nested loop bar chart
            System.out.printf("  %d star | ", r);
            for (int k = 0; k < dist[r]; k++) System.out.print('#');
            System.out.printf(" (%d)%n", dist[r]);
        }
        System.out.printf("  Average rating: %.2f / 5 from %d review(s)%n", averageRating(), feedbacks.size());
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.Give feedback  2.View all  3.Rating summary  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 3);
            switch (ch) {
                case 1: {
                    int id = Input.readInt("Order ID: ");
                    int r = Input.readIntInRange("Rating 1-5: ", 1, 5);
                    String c = Input.readLine("Comment: ");
                    try {
                        submit(id, r, c);
                        System.out.println("  Thank you for your feedback!");
                    } catch (DineSyncException e) {
                        System.out.println("  ! " + e.getMessage());
                    }
                    break;
                }
                case 2:
                    if (feedbacks.isEmpty()) System.out.println("  No feedback yet.");
                    feedbacks.forEach(f -> System.out.println("  " + f));
                    break;
                case 3:
                    showSummary();
                    break;
                default:
                    break;
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        return String.format("M07 Feedback entries   : %d | average %.2f", feedbacks.size(), averageRating());
    }
}
