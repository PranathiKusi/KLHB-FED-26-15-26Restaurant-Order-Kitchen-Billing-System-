/*
 * DineSync - DineSyncMain.java
 * Main class: creates every module, handles login, role-based menu,
 * and runs a complete end-to-end demo scenario.
 * Compile: javac *.java     Run: java DineSyncMain
 */
import java.util.Arrays;
import java.util.List;

public class DineSyncMain {

    private static final String[] MENU_LABELS = {
            "Logout",
            "Menu Management             [A-M02]",
            "Customer Profiles           [A-M03]",
            "Table Occupancy Register    [A-M09]",
            "Take New Order              [B-M04]",
            "Kitchen Queue & Token       [B-M05, M11]",
            "Billing, Payment, Checksum  [C-M06, M12]",
            "Feedback & Ratings          [C-M07]",
            "Kitchen Sensors (simulated) [D-M10]",
            "Kitchen Energy Meter        [D-M13]",
            "Reports & Analytics         [D-M08]",
            "Staff Accounts              [A-M01]",
            "Run End-to-End Demo"
    };

    // Cluster A
    private final AuthService auth = new AuthService();
    private final MenuManager menu = new MenuManager();
    private final CustomerManager customers = new CustomerManager(menu);
    private final TableRegister tables = new TableRegister();
    // Cluster B
    private final KitchenQueue kitchen = new KitchenQueue();
    private final OrderService orders = new OrderService(menu, customers, tables, kitchen);
    // Cluster C
    private final BillingService billing = new BillingService(orders, tables);
    private final FeedbackService feedback = new FeedbackService(billing);
    // Cluster D
    private final KitchenMonitor monitor = new KitchenMonitor(42L);
    private final EnergyMeter energy = new EnergyMeter();
    private final ReportService reports = new ReportService(billing, feedback, menu);

    private final RestaurantModule[] modules;     // index = main menu option

    DineSyncMain() {
        modules = new RestaurantModule[]{
                null, menu, customers, tables, orders, kitchen,
                billing, feedback, monitor, energy, reports, auth
        };
        List<Reportable> sources = Arrays.asList(auth, menu, customers, tables, orders,
                kitchen, billing, feedback, monitor, energy);
        reports.setSources(sources);
    }

    public static void main(String[] args) {
        DineSyncMain app = new DineSyncMain();
        app.run();
    }

    void printBanner() {
        Common.line('*', 64);
        System.out.println("   " + Common.RESTAURANT_NAME + "  v" + Common.VERSION);
        System.out.println("   Smart Restaurant Management System with IoT-Based Kitchen Monitoring");
        Common.line('*', 64);
        int tableCount = TableRegister.TABLE_COUNT;
        double gstPercent = (BillingService.CGST_RATE + BillingService.SGST_RATE) * 100;
        int menuSize = menu.getItems().size();
        System.out.printf("   Tables: %d | Menu items: %d | GST: %.1f%% | Sensors: simulated%n",
                tableCount, menuSize, gstPercent);
    }

    void run() {
        printBanner();
        boolean exit = false;
        while (!exit) {
            System.out.println("\n--- LOGIN ---  (demo: manager/admin123, waiter/wait123, chef/chef123)");
            Staff user = auth.loginPrompt();
            if (user != null) sessionLoop(user);
            exit = !Input.readYesNo("Login again?");
        }
        System.out.println("Thank you for using DineSync. Goodbye!");
    }

    void printMainMenu(Staff user) {
        System.out.println();
        Common.line('=', 56);
        System.out.printf("  DINESYNC MAIN MENU | %s (%s)%n", user.getName(), user.getRole());
        Common.line('=', 56);
        for (int i = 1; i < MENU_LABELS.length; i++) {
            String mark = user.canAccess(i) ? "  " : " x";
            System.out.printf("%s %2d. %s%n", mark, i, MENU_LABELS[i]);
        }
        System.out.println("    0. " + MENU_LABELS[0] + "      (x = no access for your role)");
    }

    void sessionLoop(Staff user) {
        try {
            while (true) {
                printMainMenu(user);
                int choice = Input.readIntInRange("Select option: ", 0, MENU_LABELS.length - 1);
                if (choice == 0) break;
                if (!user.canAccess(choice)) {
                    System.out.println("  ! Access denied for role " + user.getRole() + ".");
                    continue;
                }
                if (choice == 12) runDemoScenario();
                else modules[choice].processModule();          // runtime polymorphism
            }
        } finally {
            System.out.println("  Session closed for " + user.getName() + ".");
        }
    }

    void step(String text) {
        System.out.println();
        System.out.println(">> " + text);
    }

    void runDemoScenario() {
        System.out.println();
        Common.line('#', 64);
        System.out.println("  END-TO-END DEMO: one complete customer visit");
        Common.line('#', 64);
        try {
            step("1. Customer arrives (registered, vegetarian, loyalty points)");
            Customer priya = customers.find("9876543210");
            System.out.println("  " + priya);

            step("2. Allocate smallest free table for 2 guests (bitwise register)");
            int table = tables.findFreeTable(2);
            if (table == -1) throw new DineSyncException("No free table for 2 guests.");
            tables.allocate(table);
            tables.displayRegister();

            step("3. Take order with validation");
            Order order = orders.createOrder(table, priya);
            orders.addItem(order, "M01", 2);     // Paneer Butter Masala x2
            orders.addItem(order, "B01", 4);     // Butter Naan x4
            orders.addItem(order, "D01");        // Gulab Jamun x1 (overloaded method)
            try {
                orders.addItem(order, "M02", 1); // non-veg for veg customer -> rejected
            } catch (DineSyncException e) {
                System.out.println("  Validation check: " + e.getMessage());
            }
            try {
                orders.addItem(order, "B01", 50); // invalid quantity -> rejected
            } catch (DineSyncException e) {
                System.out.println("  Validation check: " + e.getMessage());
            }
            orders.submit(order);
            System.out.println(order);

            int id = order.getOrderId();
            step("4. Kitchen workflow: PLACED -> PREPARING -> READY -> SERVED");
            kitchen.startOrder(id);
            System.out.println("  Preparing by chef " + order.getChef());
            kitchen.markReady(id);
            System.out.println("  READY - token shown on seven-segment display:");
            SevenSegmentDisplay.show(order.getToken());
            kitchen.markServed(id);
            System.out.println("  Status: " + order.getStatus());

            step("5. Billing with loyalty discount, CGST and SGST");
            Bill bill = billing.generateBill(id);
            bill.print();

            step("6. Payment by UPI (checksum verified before payment)");
            billing.pay(bill, 3, bill.getTotal());
            System.out.println("  Paid via " + bill.getPaymentMethod() + ". Order status: " + order.getStatus());
            System.out.println("  Loyalty points now: " + priya.getLoyaltyPoints());

            step("7. Bill checksum security test");
            System.out.println("  Genuine bill  -> " + (BillChecksum.verify(bill.getBillNo(), bill.getTotal(), bill.getChecksum()) ? "VALID" : "INVALID"));
            System.out.println("  Altered total -> " + (BillChecksum.verify(bill.getBillNo(), bill.getTotal() + 50, bill.getChecksum()) ? "VALID" : "INVALID"));

            step("8. Feedback (duplicate prevention)");
            feedback.submit(id, 5, "Loved the paneer!");
            System.out.println("  Feedback recorded.");
            try {
                feedback.submit(id, 4, "Second try");
            } catch (DineSyncException e) {
                System.out.println("  Validation check: " + e.getMessage());
            }

            step("9. Table released after payment");
            tables.displayRegister();

            step("10. Kitchen safety check (3 simulated cycles) and energy estimate");
            monitor.runCycles(3);
            System.out.println("  " + energy.generateReport());

            step("11. Daily report");
            reports.buildReport().forEach(System.out::println);

        } catch (DineSyncException e) {
            System.out.println("  ! Demo stopped: " + e.getMessage());
        } finally {
            System.out.println("\n  Demo finished.");
        }
    }
}
