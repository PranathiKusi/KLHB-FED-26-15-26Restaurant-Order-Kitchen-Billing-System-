/*
 * DineSync - ClusterA.java
 * Cluster A: Identity, Menu, Customers and Tables
 *   M01 Login & Access Control       -> Staff, Manager, Waiter, Chef, AuthService
 *   M02 Menu Management              -> MenuItem, MenuManager
 *   M03 Customer Profile & Favourites-> Customer, CustomerManager
 *   M09 Table Occupancy Register     -> TableRegister (bitwise operators)
 */
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

/* ============================ M01 LOGIN ============================ */

abstract class Staff extends Person {
    private final String username;
    private final String password;            // private, no getter (encapsulation)

    Staff(String id, String name, String username, String password) {
        super(id, name);
        this.username = username;
        this.password = password;
    }

    String getUsername() { return username; }

    boolean checkPassword(String attempt) {
        return password.equals(attempt);       // equals() = value comparison
    }

    abstract boolean canAccess(int menuOption);
}

class Manager extends Staff {
    Manager(String id, String name, String user, String pass) { super(id, name, user, pass); }
    @Override String getRole() { return "MANAGER"; }
    @Override boolean canAccess(int menuOption) { return true; }
}

class Waiter extends Staff {
    Waiter(String id, String name, String user, String pass) { super(id, name, user, pass); }
    @Override String getRole() { return "WAITER"; }
    @Override boolean canAccess(int menuOption) {
        switch (menuOption) {
            case 1: case 2: case 3: case 4: case 6: case 7: case 12:
                return true;
            default:
                return false;
        }
    }
}

class Chef extends Staff {
    Chef(String id, String name, String user, String pass) { super(id, name, user, pass); }
    @Override String getRole() { return "CHEF"; }
    @Override boolean canAccess(int menuOption) {
        return menuOption == 1 || menuOption == 5 || menuOption == 8
                || menuOption == 9 || menuOption == 12;
    }
}

class AuthService extends RestaurantModule {
    static final int MAX_ATTEMPTS = 3;
    private final Map<String, Staff> users = new HashMap<>();

    AuthService() {
        super("M01", "Login & Access Control");
        addStaff(new Manager("S01", "Ravi Kumar", "manager", "admin123"));
        addStaff(new Waiter("S02", "Anitha", "waiter", "wait123"));
        addStaff(new Chef("S03", "Suresh", "chef", "chef123"));
    }

    void addStaff(Staff s) { users.put(s.getUsername().toLowerCase(), s); }

    Staff authenticate(String username, String password) throws DineSyncException {
        if (username.isEmpty() || password.isEmpty())
            throw new DineSyncException("Username and password cannot be empty.");
        Staff s = users.get(username.toLowerCase());
        if (s == null || !s.checkPassword(password))
            throw new DineSyncException("Invalid username or password.");
        return s;
    }

    Staff loginPrompt() {
        int attempts = 0;
        do {
            String user = Input.readLine("Username: ");
            String pass = Input.readLine("Password: ");
            try {
                Staff s = authenticate(user, pass);
                System.out.printf("  Login successful. Welcome %s (%s)%n", s.getName(), s.getRole());
                return s;
            } catch (DineSyncException e) {
                attempts++;
                System.out.printf("  ! %s Attempts left: %d%n", e.getMessage(), MAX_ATTEMPTS - attempts);
            }
        } while (attempts < MAX_ATTEMPTS);
        System.out.println("  ! Too many failed attempts. Login locked.");
        return null;
    }

    @Override
    void processModule() {
        displayModuleInfo();
        System.out.printf("%-6s %-18s %-10s%n", "ID", "NAME", "ROLE");
        users.values().stream()
                .sorted(Comparator.comparing(Person::getId))
                .forEach(System.out::println);                 // method reference

        if (!Input.readYesNo("Add a new staff member?")) return;
        String name = Input.readLine("Name: ");
        String user = Input.readLine("Username: ").toLowerCase();
        String pass = Input.readLine("Password (min 6 chars): ");
        int role = Input.readIntInRange("Role 1-Manager 2-Waiter 3-Chef: ", 1, 3);

        if (name.isEmpty() || user.isEmpty() || pass.length() < 6) {
            System.out.println("  ! Name/username required and password must be 6+ characters.");
            return;
        }
        if (users.containsKey(user)) {
            System.out.println("  ! Username already exists.");
            return;
        }
        String id = String.format("S%02d", users.size() + 1);
        Staff s = (role == 1) ? new Manager(id, name, user, pass)
                : (role == 2) ? new Waiter(id, name, user, pass)
                : new Chef(id, name, user, pass);
        addStaff(s);
        System.out.println("  Staff added: " + s);
    }

    @Override
    public String generateReport() {
        Map<String, Long> byRole = users.values().stream()
                .collect(Collectors.groupingBy(Staff::getRole, TreeMap::new, Collectors.counting()));
        return "M01 Staff accounts     : " + users.size() + " " + byRole;
    }
}

/* ============================ M02 MENU ============================ */

class MenuItem implements Comparable<MenuItem> {
    private final String code;
    private final String name;
    private final String category;
    private double price;
    private final boolean veg;
    private boolean available;

    MenuItem(String code, String name, String category, double price, boolean veg) {
        this(code, name, category, price, veg, true);          // constructor chaining
    }

    MenuItem(String code, String name, String category, double price, boolean veg, boolean available) {
        if (name == null || name.trim().isEmpty() || name.contains(","))
            throw new InvalidInputException("Item name must be non-empty and contain no commas.");
        if (category == null || category.trim().isEmpty() || category.contains(","))
            throw new InvalidInputException("Category must be non-empty and contain no commas.");
        this.code = code.toUpperCase();
        this.name = name.trim();
        this.category = category.trim();
        this.veg = veg;
        this.available = available;
        setPrice(price);
    }

    String getCode() { return code; }
    String getName() { return name; }
    String getCategory() { return category; }
    double getPrice() { return price; }
    boolean isVeg() { return veg; }
    boolean isAvailable() { return available; }

    void setAvailable(boolean available) { this.available = available; }

    void setPrice(double price) {
        if (price <= 0 || price > 10000)
            throw new InvalidInputException("Price must be between 1 and 10000.");
        this.price = price;
    }

    @Override
    public int compareTo(MenuItem other) {        // natural order = item code
        return this.code.compareTo(other.code);
    }

    String toCsv() {
        return String.join(",", code, name, category, String.valueOf(price),
                String.valueOf(veg), String.valueOf(available));
    }

    static MenuItem fromCsv(String line) {
        String[] p = line.split(",");
        return new MenuItem(p[0].trim(), p[1].trim(), p[2].trim(),
                Double.parseDouble(p[3].trim()),
                Boolean.parseBoolean(p[4].trim()),
                Boolean.parseBoolean(p[5].trim()));
    }

    @Override
    public String toString() {
        return String.format("%-5s %-22s %-10s %8.2f  %-7s %s", code, name, category, price,
                veg ? "VEG" : "NON-VEG", available ? "" : "(unavailable)");
    }
}

class MenuManager extends RestaurantModule {
    private static final Path MENU_FILE = Paths.get("menu.csv");
    private final List<MenuItem> items = new ArrayList<>();

    MenuManager() {
        super("M02", "Menu Management");
        loadMenu();
    }

    private void loadDefaults() {
        items.clear();
        items.add(new MenuItem("S01", "Veg Manchurian", "Starter", 180, true));
        items.add(new MenuItem("S02", "Chicken 65", "Starter", 240, false));
        items.add(new MenuItem("M01", "Paneer Butter Masala", "Main", 260, true));
        items.add(new MenuItem("M02", "Chicken Biryani", "Main", 320, false));
        items.add(new MenuItem("M03", "Veg Fried Rice", "Main", 200, true));
        items.add(new MenuItem("B01", "Butter Naan", "Bread", 50, true));
        items.add(new MenuItem("D01", "Gulab Jamun", "Dessert", 90, true));
        items.add(new MenuItem("V01", "Fresh Lime Soda", "Beverage", 70, true));
    }

    void loadMenu() {
        items.clear();
        if (!Files.exists(MENU_FILE)) {
            loadDefaults();
            saveMenu();
            System.out.println("  (menu.csv not found - default menu created)");
            return;
        }
        int bad = 0;
        try (BufferedReader br = Files.newBufferedReader(MENU_FILE)) {   // try-with-resources
            String line;
            while ((line = br.readLine()) != null) {
                if (line.isBlank() || line.startsWith("#")) continue;
                try {
                    items.add(MenuItem.fromCsv(line));
                } catch (NumberFormatException | ArrayIndexOutOfBoundsException e) {
                    bad++;                                               // malformed record
                } catch (InvalidInputException e) {
                    bad++;
                }
            }
        } catch (IOException e) {
            System.out.println("  ! Could not read menu.csv: " + e.getMessage());
        }
        if (bad > 0) System.out.println("  ! Skipped " + bad + " malformed menu record(s).");
        if (items.isEmpty()) loadDefaults();
    }

    void saveMenu() {
        try (BufferedWriter bw = Files.newBufferedWriter(MENU_FILE)) {
            bw.write("# code,name,category,price,veg,available");
            bw.newLine();
            for (MenuItem m : items) {
                bw.write(m.toCsv());
                bw.newLine();
            }
        } catch (IOException e) {
            System.out.println("  ! Could not save menu.csv: " + e.getMessage());
        }
    }

    List<MenuItem> getItems() { return items; }

    List<MenuItem> getAvailableItems() {
        return items.stream().filter(MenuItem::isAvailable).collect(Collectors.toList());
    }

    MenuItem findByCode(String code) {                     // linear search (CO3)
        for (int i = 0; i < items.size(); i++) {
            if (items.get(i).getCode().equalsIgnoreCase(code)) return items.get(i);
        }
        return null;
    }

    Optional<MenuItem> search(String code) {
        return Optional.ofNullable(findByCode(code));
    }

    int binarySearchCode(String code) {                    // library algorithm (CO5)
        String[] codes = new String[items.size()];
        for (int i = 0; i < codes.length; i++) codes[i] = items.get(i).getCode();
        Arrays.sort(codes);
        return Arrays.binarySearch(codes, code.toUpperCase());
    }

    void display(List<MenuItem> list) {
        if (list.isEmpty()) {
            System.out.println("  (no items)");
            return;
        }
        System.out.printf("%-5s %-22s %-10s %8s  %-7s%n", "CODE", "ITEM", "CATEGORY", "PRICE", "TYPE");
        Common.line();
        list.forEach(System.out::println);
    }

    static boolean isValidCode(String code) {
        return code.length() == 3 && Character.isLetter(code.charAt(0))
                && Character.isDigit(code.charAt(1)) && Character.isDigit(code.charAt(2));
    }

    private void addItemInteractive() {
        String code = Input.readLine("New item code (e.g. S03): ").toUpperCase();
        if (!isValidCode(code)) {
            System.out.println("  ! Code must be 1 letter followed by 2 digits.");
            return;
        }
        if (findByCode(code) != null) {
            System.out.println("  ! Code already exists.");
            return;
        }
        String name = Input.readLine("Item name: ");
        String category = Input.readLine("Category (Starter/Main/Bread/Dessert/Beverage): ");
        double price = Input.readDouble("Price (Rs): ");
        boolean veg = Input.readYesNo("Vegetarian?");
        try {
            items.add(new MenuItem(code, name, category, price, veg));
            saveMenu();
            System.out.println("  Item added and menu.csv updated.");
        } catch (InvalidInputException e) {
            System.out.println("  ! " + e.getMessage());
        }
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.View  2.Sort by price  3.Sort by name  4.Veg only  5.Search"
                    + "  6.Add item  7.Toggle availability  8.Update price  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 8);
            switch (ch) {
                case 1:
                    Collections.sort(items);                       // Comparable
                    display(items);
                    break;
                case 2: {
                    List<MenuItem> byPrice = new ArrayList<>(items);
                    byPrice.sort(Comparator.comparingDouble(MenuItem::getPrice));
                    display(byPrice);
                    break;
                }
                case 3: {
                    List<MenuItem> byName = new ArrayList<>(items);
                    byName.sort((a, b) -> a.getName().compareToIgnoreCase(b.getName()));  // lambda Comparator
                    display(byName);
                    break;
                }
                case 4:
                    display(items.stream().filter(MenuItem::isVeg).collect(Collectors.toList()));
                    break;
                case 5: {
                    String code = Input.readLine("Item code: ").toUpperCase();
                    Optional<MenuItem> found = search(code);
                    found.ifPresent(m -> System.out.println("  Linear search found: " + m));
                    if (!found.isPresent()) System.out.println("  Item not found.");
                    System.out.println("  Binary search index (negative = not found): " + binarySearchCode(code));
                    break;
                }
                case 6:
                    addItemInteractive();
                    break;
                case 7: {
                    MenuItem m = findByCode(Input.readLine("Item code: "));
                    if (m == null) { System.out.println("  ! Not found."); break; }
                    m.setAvailable(!m.isAvailable());
                    saveMenu();
                    System.out.println("  " + m.getName() + " is now " + (m.isAvailable() ? "AVAILABLE" : "UNAVAILABLE"));
                    break;
                }
                case 8: {
                    MenuItem m = findByCode(Input.readLine("Item code: "));
                    if (m == null) { System.out.println("  ! Not found."); break; }
                    try {
                        m.setPrice(Input.readDouble("New price: "));
                        saveMenu();
                        System.out.println("  Updated: " + m);
                    } catch (InvalidInputException e) {
                        System.out.println("  ! " + e.getMessage());
                    }
                    break;
                }
                default:
                    break;
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        long veg = items.stream().filter(MenuItem::isVeg).count();
        long unavailable = items.stream().filter(m -> !m.isAvailable()).count();
        double avg = items.stream().mapToDouble(MenuItem::getPrice).average().orElse(0);
        return String.format("M02 Menu items         : %d | veg %d | unavailable %d | avg price %.2f",
                items.size(), veg, unavailable, avg);
    }
}

/* ============================ M03 CUSTOMERS ============================ */

class Customer extends Person {
    private final String phone;
    private final boolean vegetarian;
    private int loyaltyPoints;
    private int visits;
    private final Set<String> favourites = new HashSet<>();   // no duplicates

    Customer(String id, String name, String phone, boolean vegetarian) {
        super(id, name);
        this.phone = phone;
        this.vegetarian = vegetarian;
    }

    String getPhone() { return phone; }
    boolean isVegetarian() { return vegetarian; }
    int getLoyaltyPoints() { return loyaltyPoints; }
    int getVisits() { return visits; }
    Set<String> getFavourites() { return favourites; }

    void addLoyaltyPoints(int points) {
        if (points > 0) loyaltyPoints += points;
    }

    void incrementVisits() { visits++; }

    boolean addFavourite(String code) { return favourites.add(code); }

    @Override String getRole() { return "CUSTOMER"; }

    @Override
    public String toString() {
        return String.format("%-5s %-16s %-11s %-8s %4d pts  visits %d  fav %s", id, name, phone,
                vegetarian ? "VEG" : "NON-VEG", loyaltyPoints, visits, favourites);
    }
}

class CustomerManager extends RestaurantModule {
    private final Map<String, Customer> byPhone = new HashMap<>();
    private final MenuManager menu;
    private int nextId = 1;

    CustomerManager(MenuManager menu) {
        super("M03", "Customer Profile & Favourites");
        this.menu = menu;
        try {                                              // sample customers
            Customer c1 = register("priya sharma", "9876543210", true);
            c1.addLoyaltyPoints(120);
            c1.addFavourite("M01");
            Customer c2 = register("RAHUL VERMA", "9123456780", false);
            c2.addLoyaltyPoints(250);
            c2.addFavourite("M02");
            register("kiran rao", "9988776655", false);
        } catch (DineSyncException e) {
            System.out.println("  ! Sample data error: " + e.getMessage());
        }
    }

    static boolean isValidPhone(String phone) {
        if (phone == null || phone.length() != 10) return false;
        char first = phone.charAt(0);
        if (first < '6' || first > '9') return false;
        for (char c : phone.toCharArray()) {
            if (!Character.isDigit(c)) return false;
        }
        return true;
    }

    static boolean isValidName(String name) {
        if (name.isEmpty()) return false;
        for (int i = 0; i < name.length(); i++) {
            char ch = name.charAt(i);
            if (!Character.isLetter(ch) && ch != ' ') return false;
        }
        return true;
    }

    static String toProperCase(String raw) {               // String + StringBuilder (CO5)
        String[] words = raw.trim().toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder();
        for (String w : words) {
            if (w.isEmpty()) continue;
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }

    Customer register(String name, String phone, boolean vegetarian) throws DineSyncException {
        String cleanName = toProperCase(name);
        if (!isValidName(cleanName)) throw new DineSyncException("Name must contain only letters and spaces.");
        if (!isValidPhone(phone)) throw new DineSyncException("Phone must be 10 digits starting with 6-9.");
        if (byPhone.containsKey(phone)) throw new DineSyncException("Customer with phone " + phone + " already exists.");
        Customer c = new Customer(String.format("C%03d", nextId++), cleanName, phone, vegetarian);
        byPhone.put(phone, c);
        return c;
    }

    Customer find(String phone) { return byPhone.get(phone); }

    Collection<Customer> getAll() { return byPhone.values(); }

    private void addFavouriteInteractive() {
        Customer c = find(Input.readLine("Customer phone: "));
        if (c == null) { System.out.println("  ! Customer not found."); return; }
        MenuItem m = menu.findByCode(Input.readLine("Menu item code: "));
        if (m == null) { System.out.println("  ! Menu item not found."); return; }
        if (c.isVegetarian() && !m.isVeg()) {
            System.out.println("  ! " + c.getName() + " is vegetarian. " + m.getName() + " is non-veg.");
            return;
        }
        System.out.println(c.addFavourite(m.getCode()) ? "  Added to favourites." : "  Already a favourite.");
    }

    private void listAll() {
        Map<String, Customer> sorted = new TreeMap<>();     // ordered map: A-Z by name
        for (Customer c : byPhone.values()) sorted.put(c.getName() + c.getPhone(), c);
        for (Customer c : sorted.values()) System.out.println("  " + c);
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.Register  2.Find by phone  3.Add favourite  4.List all (A-Z)  5.Top loyalty  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 5);
            switch (ch) {
                case 1: {
                    String name = Input.readLine("Name: ");
                    String phone = Input.readLine("Phone (10 digits): ");
                    boolean veg = Input.readYesNo("Vegetarian?");
                    try {
                        System.out.println("  Registered: " + register(name, phone, veg));
                    } catch (DineSyncException e) {
                        System.out.println("  ! " + e.getMessage());
                    }
                    break;
                }
                case 2: {
                    Customer c = find(Input.readLine("Phone: "));
                    System.out.println(c == null ? "  Customer not found." : "  " + c);
                    break;
                }
                case 3:
                    addFavouriteInteractive();
                    break;
                case 4:
                    listAll();
                    break;
                case 5:
                    byPhone.values().stream()
                            .sorted(Comparator.comparingInt(Customer::getLoyaltyPoints).reversed())
                            .limit(3)
                            .forEach(c -> System.out.println("  " + c));
                    break;
                default:
                    break;
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        long veg = byPhone.values().stream().filter(Customer::isVegetarian).count();
        return "M03 Customers          : " + byPhone.size() + " | vegetarian " + veg;
    }
}

/* ============================ M09 TABLE REGISTER ============================ */

class TableRegister extends RestaurantModule {
    static final int TABLE_COUNT = 8;
    private final int[] capacity = {2, 2, 4, 4, 4, 6, 6, 8};
    private int occupancy = 0;          // bit (n-1) = 1 means table n is occupied

    TableRegister() {
        super("M09", "Table Occupancy Register (bitwise)");
    }

    private void validateTableNo(int tableNo) throws DineSyncException {
        if (tableNo < 1 || tableNo > TABLE_COUNT)
            throw new DineSyncException("Table number must be 1 to " + TABLE_COUNT + ".");
    }

    boolean isOccupied(int tableNo) {
        return (occupancy & (1 << (tableNo - 1))) != 0;       // bitwise AND + left shift
    }

    void allocate(int tableNo) throws DineSyncException {
        validateTableNo(tableNo);
        if (isOccupied(tableNo)) throw new DineSyncException("Table " + tableNo + " is already occupied.");
        occupancy |= (1 << (tableNo - 1));                    // set bit
    }

    void release(int tableNo) throws DineSyncException {
        validateTableNo(tableNo);
        if (!isOccupied(tableNo)) throw new DineSyncException("Table " + tableNo + " is already free.");
        occupancy &= ~(1 << (tableNo - 1));                   // clear bit
    }

    int getCapacity(int tableNo) { return capacity[tableNo - 1]; }

    int findFreeTable(int guests) {                           // smallest free table that fits
        for (int i = 0; i < TABLE_COUNT; i++) {
            if (capacity[i] >= guests && !isOccupied(i + 1)) return i + 1;
        }
        return -1;
    }

    int countOccupied() {
        int count = 0;
        int bits = occupancy;
        while (bits != 0) {
            count += bits & 1;
            bits >>>= 1;                                      // unsigned right shift
        }
        return count;
    }

    String binaryView() {
        String bin = Integer.toBinaryString(occupancy);
        StringBuilder sb = new StringBuilder();
        for (int i = bin.length(); i < TABLE_COUNT; i++) sb.append('0');
        return sb.append(bin).toString();
    }

    void displayRegister() {
        System.out.println("  Occupancy bits (T8..T1): " + binaryView() + "  = decimal " + occupancy);
        for (int t = 1; t <= TABLE_COUNT; t++) {
            System.out.printf("  T%d [%d seats] %s%n", t, capacity[t - 1], isOccupied(t) ? "OCCUPIED" : "free");
        }
        double percent = (double) countOccupied() / TABLE_COUNT * 100;   // explicit cast
        System.out.printf("  Occupied: %d/%d (%.1f%%)%n", countOccupied(), TABLE_COUNT, percent);
    }

    @Override
    void processModule() {
        displayModuleInfo();
        int ch;
        do {
            System.out.println("\n1.View register  2.Allocate table  3.Release table  0.Back");
            ch = Input.readIntInRange("Choice: ", 0, 3);
            switch (ch) {
                case 1:
                    displayRegister();
                    break;
                case 2: {
                    int guests = Input.readIntInRange("Number of guests (1-8): ", 1, 8);
                    int t = findFreeTable(guests);
                    if (t == -1) {
                        System.out.println("  ! No free table can seat " + guests + " guests.");
                        break;
                    }
                    try {
                        allocate(t);
                        System.out.printf("  Table %d (%d seats) allocated.%n", t, getCapacity(t));
                    } catch (DineSyncException e) {
                        System.out.println("  ! " + e.getMessage());
                    }
                    break;
                }
                case 3: {
                    int t = Input.readIntInRange("Table to release: ", 1, TABLE_COUNT);
                    try {
                        release(t);
                        System.out.println("  Table " + t + " released.");
                    } catch (DineSyncException e) {
                        System.out.println("  ! " + e.getMessage());
                    }
                    break;
                }
                default:
                    break;
            }
        } while (ch != 0);
    }

    @Override
    public String generateReport() {
        return "M09 Tables occupied    : " + countOccupied() + "/" + TABLE_COUNT + " bits " + binaryView();
    }
}
